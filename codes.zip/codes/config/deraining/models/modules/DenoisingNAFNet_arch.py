import torch
import torch.nn as nn
import torch.nn.functional as F
from einops import rearrange, reduce
from thop import profile
from .module_util import SinusoidalPosEmb, LayerNorm, exists


class SimpleGate(nn.Module):
    def forward(self, x):
        x1, x2 = x.chunk(2, dim=1)
        return x1 * x2

#class Simam_module(torch.nn.Module):
#    def __init__(self, e_lambda=1e-4):
#        super(Simam_module, self).__init__()
#        self.act = nn.Sigmoid()
#        self.e_lambda = e_lambda
#
#    def forward(self, x):
#        b, c, h, w = x.size()
#        n = w * h - 1
#        x_minus_mu_square = (x - x.mean(dim=[2, 3], keepdim=True)).pow(2)
#        y = x_minus_mu_square / (4 * (x_minus_mu_square.sum(dim=[2, 3], keepdim=True) / n + self.e_lambda)) + 0.5
#
#        return x * self.act(y)

class Simam(torch.nn.Module):
    def __init__(self, e_lambda=1e-4):
        super(Simam, self).__init__()
        self.act = nn.Sigmoid()
        self.e_lambda = e_lambda

    def forward(self, x):
        b, c, h, w = x.size()
        n = w * h - 1
        x_minus_mu_square = (x - x.mean(dim=[2, 3], keepdim=True)).pow(2)
        y = x_minus_mu_square / (4 * (x_minus_mu_square.sum(dim=[2, 3], keepdim=True) / n + self.e_lambda)) + 0.5
        y = self.act(y)
        #return x * self.act(y)
        return y


class CGAFusion(nn.Module):
    def __init__(self, dim, reduction=8):
        super(CGAFusion, self).__init__()
        self.sim = Simam()
        self.conv = nn.Conv2d(dim, dim, 1, bias=True)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x, y):
        initial = x + y
        pattn2 = self.sim(initial)       
        result = initial + pattn2 * x + (1 - pattn2) * y
        result = self.conv(result)
        return result

class NAFBlock(nn.Module):
    def __init__(self, c, time_emb_dim=None, DW_Expand=2, FFN_Expand=2, drop_out_rate=0.):
        super().__init__()
        self.mlp = nn.Sequential(
            SimpleGate(), nn.Linear(time_emb_dim // 2, c * 4)
        ) if time_emb_dim else None

        dw_channel = c * DW_Expand
        self.conv1 = nn.Conv2d(in_channels=c, out_channels=dw_channel, kernel_size=1, padding=0, stride=1, groups=1, bias=True)
        self.conv2 = nn.Conv2d(in_channels=dw_channel, out_channels=dw_channel, kernel_size=3, padding=1, stride=1, groups=dw_channel,
                               bias=True)
        self.conv3 = nn.Conv2d(in_channels=dw_channel // 2, out_channels=c, kernel_size=1, padding=0, stride=1, groups=1, bias=True)
        
        # Simplified Channel Attention
        self.sca = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(in_channels=dw_channel // 2, out_channels=dw_channel // 2, kernel_size=1, padding=0, stride=1,
                      groups=1, bias=True),
        )

        #self.siam = Simam_module()
        # SimpleGate
        self.sg = SimpleGate()

        ffn_channel = FFN_Expand * c
        self.conv4 = nn.Conv2d(in_channels=c, out_channels=ffn_channel, kernel_size=1, padding=0, stride=1, groups=1, bias=True)
        self.conv5 = nn.Conv2d(in_channels=ffn_channel // 2, out_channels=c, kernel_size=1, padding=0, stride=1, groups=1, bias=True)

        self.norm1 = LayerNorm(c)
        self.norm2 = LayerNorm(c)

        self.dropout1 = nn.Dropout(drop_out_rate) if drop_out_rate > 0. else nn.Identity()
        self.dropout2 = nn.Dropout(drop_out_rate) if drop_out_rate > 0. else nn.Identity()

        self.beta = nn.Parameter(torch.zeros((1, c, 1, 1)), requires_grad=True)
        self.gamma = nn.Parameter(torch.zeros((1, c, 1, 1)), requires_grad=True)

    def time_forward(self, time, mlp):
        time_emb = mlp(time)
        time_emb = rearrange(time_emb, 'b c -> b c 1 1')
        return time_emb.chunk(4, dim=1)

    def forward(self, x):
        inp, time = x
        shift_att, scale_att, shift_ffn, scale_ffn = self.time_forward(time, self.mlp)

        x = inp

        x = self.norm1(x)
        x = x * (scale_att + 1) + shift_att
        x = self.conv1(x)
        x = self.conv2(x)
        x = self.sg(x)
        x = x * self.sca(x)
        #x = self.siam(x)
        x = self.conv3(x)

        x = self.dropout1(x)

        y = inp + x * self.beta

        x = self.norm2(y)
        x = x * (scale_ffn + 1) + shift_ffn
        x = self.conv4(x)
        x = self.sg(x)
        x = self.conv5(x)

        x = self.dropout2(x)

        x = y + x * self.gamma

        return x, time


class make_fdense(nn.Module):
    def __init__(self, nChannels, growthRate, kernel_size=1):
        super(make_fdense, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(nChannels, growthRate, kernel_size=kernel_size, padding=(kernel_size - 1) // 2,
                              bias=False),nn.BatchNorm2d(growthRate)
        )
        self.bat = nn.BatchNorm2d(growthRate),
        self.leaky=nn.LeakyReLU(0.1,inplace=True)
        self.sg = SimpleGate()

    def forward(self, x):
        out = self.leaky(self.conv(x))
        #out = self.sg(self.conv(x))
        out = torch.cat((x, out), 1)
        return out
    
class FRDB(nn.Module):
    def __init__(self, nChannels, nDenselayer=2, growthRate=32):
        super(FRDB, self).__init__()

        self.mlp = nn.Sequential(
            SimpleGate(), nn.Linear(128, nChannels*4)
        ) 

        nChannels_1 = nChannels
        nChannels_2 = nChannels
        modules1 = []

        tong = int(growthRate/2)

        for i in range(nDenselayer):
            modules1.append(make_fdense(nChannels_1, growthRate))
            nChannels_1 += growthRate
        self.dense_layers1 = nn.Sequential(*modules1)

        modules2 = []
        for i in range(nDenselayer):
            modules2.append(make_fdense(nChannels_2, growthRate))
            nChannels_2 += growthRate
        self.dense_layers2 = nn.Sequential(*modules2)
        self.conv_1 = nn.Conv2d(nChannels_1, nChannels, kernel_size=1, padding=0, bias=False)
        self.conv_2 = nn.Conv2d(nChannels_2, nChannels, kernel_size=1, padding=0, bias=False)
        
    def time_forward(self, time, mlp):
        time_emb = mlp(time)
 

        time_emb = rearrange(time_emb, 'b c -> b c 1 1')


        return time_emb.chunk(4, dim=1)


    def forward(self, inp):
        x, t = inp
        _, _, H, W = x.shape
        shift_att, scale_att, shift_ffn, scale_ffn = self.time_forward(t, self.mlp)
        
        #print("!!!!!!!!")
        #print(x.shape)
        x_freq = torch.fft.rfft2(x, norm='backward')
        #print(x_freq.shape)
        mag = torch.abs(x_freq)
        #print(mag.shape)
        pha = torch.angle(x_freq)
        #print(pha.shape)

        mag = mag * (scale_att + 1) + shift_att
        mag = self.dense_layers1(mag)
        #print(mag.shape)
        mag = self.conv_1(mag)
        #print(mag.shape)
        #print("!!!!!!!!")
        #exit()

        pha = pha * (scale_ffn + 1) + shift_ffn
        pha = self.dense_layers2(pha)
        pha = self.conv_2(pha)

        real = mag * torch.cos(pha)
        imag = mag * torch.sin(pha)
        x_out = torch.complex(real, imag)
        out = torch.fft.irfft2(x_out, s=(H, W), norm='backward')
        out = out + x
        return out,t



class ConditionalNAFNet(nn.Module):

    def __init__(self, img_channel=3, width=16, middle_blk_num=1, enc_blk_nums=[], dec_blk_nums=[], upscale=1):
        super().__init__()
        self.upscale = upscale
        fourier_dim = width
        sinu_pos_emb = SinusoidalPosEmb(fourier_dim)
        time_dim = width * 4

        self.time_mlp = nn.Sequential(
            sinu_pos_emb,
            nn.Linear(fourier_dim, time_dim*2),
            SimpleGate(),
            nn.Linear(time_dim, time_dim)
        )

        self.intro = nn.Conv2d(in_channels=img_channel*2, out_channels=width, kernel_size=3, padding=1, stride=1, groups=1,
                              bias=True)
        self.ending = nn.Conv2d(in_channels=width, out_channels=img_channel, kernel_size=3, padding=1, stride=1, groups=1,
                              bias=True)

        self.encoders = nn.ModuleList()
        self.pinyus = nn.ModuleList()
        self.fusions = nn.ModuleList()
        self.decoders = nn.ModuleList()
        self.dpinyus = nn.ModuleList()
        self.middle_blks = nn.ModuleList()
        self.dfusions = nn.ModuleList()
        self.ups = nn.ModuleList()
        self.downs = nn.ModuleList()

        chan = width
        for num in enc_blk_nums:
            self.encoders.append(
                nn.Sequential(
                    #FRDB(nChannels=chan),
                    *[NAFBlock(chan, time_dim) for _ in range(num)]
                )
            )

            self.pinyus.append(
                FRDB(nChannels=chan)
            )
            
            self.fusions.append(
                CGAFusion(chan)
            )

            self.downs.append(
                nn.Conv2d(chan, 2*chan, 2, 2)
            )
            chan = chan * 2

        self.middle_blks = \
            nn.Sequential(
                *[NAFBlock(chan, time_dim) for _ in range(middle_blk_num)]
            )

        for num in dec_blk_nums:
            self.ups.append(
                nn.Sequential(
                    nn.Conv2d(chan, chan * 2, 1, bias=False),
                    nn.PixelShuffle(2)
                )
            )
            chan = chan // 2

            self.dpinyus.append(
                FRDB(nChannels=chan)
            )

            self.dfusions.append(
                CGAFusion(chan)
            )

            self.decoders.append(
                nn.Sequential(
                    #FRDB(nChannels=chan),
                    *[NAFBlock(chan, time_dim) for _ in range(num)]
                )
            )


        self.padder_size = 2 ** len(self.encoders)

    def forward(self, inp, cond, time):
        inp_res = inp.clone()

        if isinstance(time, int) or isinstance(time, float):
            time = torch.tensor([time]).to(inp.device)

        x = inp - cond
        x = torch.cat([x, cond], dim=1)

        t = self.time_mlp(time)

        B, C, H, W = x.shape
        x = self.check_image_size(x)

        x = self.intro(x)

        encs = []

        for encoder, pinyu, fusion, down in zip(self.encoders, self.pinyus, self.fusions, self.downs):
            x1, _ = encoder([x, t])
            x2, _ = pinyu([x, t])
            x = fusion(x1,x2)
            encs.append(x)
            x = down(x)

        x, _ = self.middle_blks([x, t])

        for decoder, dpinyu, dfusion, up, enc_skip in zip(self.decoders, self.dpinyus, self.dfusions, self.ups, encs[::-1]):
            x = up(x)
            x = x + enc_skip
            x1, _ = dpinyu([x, t])
            x2, _ = decoder([x, t])
            x = dfusion(x1,x2)

        x = self.ending(x)

        x = x[..., :H, :W]

        return x

    def check_image_size(self, x):
        _, _, h, w = x.size()
        mod_pad_h = (self.padder_size - h % self.padder_size) % self.padder_size
        mod_pad_w = (self.padder_size - w % self.padder_size) % self.padder_size
        x = F.pad(x, (0, mod_pad_w, 0, mod_pad_h))
        return x

#if __name__ == '__main__':
#    model = ConditionalNAFNet(width=64, enc_blk_nums=[1, 1, 1, 1], middle_blk_num=1, dec_blk_nums=[1, 1, 1, 1]).cuda()
#    x = torch.randn(1, 3, 128, 128).cuda()
#    cond = torch.randn(1, 3, 128, 128).cuda()
#    t = 8
#    y = model(x,cond,t)
#       
#    print("!!!!!")
#    print(model)
#    #print(y.size())
#    flops, params = profile(model, (x,cond,t))
#    print('flops: ', flops, 'params: ', params)
#    print('flops: %.2f M, params: %.2f M' % (flops / 1000000.0, params / 1000000.0))
#
